package cn.itbaizhan.model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//彩票统计
@Entity
@Table(name="t_Tongji")
public class Tongji implements Serializable{
	
	private static final long serialVersionUID = -117947798302585032L;

	private int id;//主键
	
	private Product product;
	
	private int xiaoliang;//销量
	
	private double zongjine;//总金额


	
	@Id
	@GeneratedValue
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	

	

	
	
	@ManyToOne
	@JoinColumn(name="productid")
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getXiaoliang() {
		return xiaoliang;
	}

	public void setXiaoliang(int xiaoliang) {
		this.xiaoliang = xiaoliang;
	}

	public double getZongjine() {
		return zongjine;
	}

	public void setZongjine(double zongjine) {
		this.zongjine = zongjine;
	}

	

	

	

	

	

	

	
	
	
	
	
}

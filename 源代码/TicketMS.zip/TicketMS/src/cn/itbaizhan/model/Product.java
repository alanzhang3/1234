package cn.itbaizhan.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//彩票
@Entity
@Table(name="t_Product")
public class Product implements Serializable{
	
	private static final long serialVersionUID = -117947798302585032L;

	private int id;//主键
	
	private String name;//彩票名
	
	private int productlock;
	
	private String imgpath;//彩票图片
	
	private double price1;//原价

	private double price2;//优惠价
	
	private double price3;//优惠幅度
	
	private Date createtime;//添加时间
	
	private Fenlei fenlei;//彩票分类
	
	private String info;//彩票简介
	
	private int xiaoliang;//销量
	
	private int kucun;//库存
	
	private int haoping;//好评
	
	private int zhongping;//中评
	
	private int chaping;//差评
	
	private String xinpingtuijian;//新品推荐
	
	private String hot;//热销推荐
	
	private String tejiacuxiao;//特价促销
	
	private String tebieytuijian;//特别推荐
	
	private int pingjiashuliang;//评价数
	
	

	
	public int getPingjiashuliang() {
		return pingjiashuliang;
	}

	public void setPingjiashuliang(int pingjiashuliang) {
		this.pingjiashuliang = pingjiashuliang;
	}

	public double getPrice3() {
		return price3;
	}

	public void setPrice3(double price3) {
		this.price3 = price3;
	}

	@Id
	@GeneratedValue
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getProductlock() {
		return productlock;
	}

	public void setProductlock(int productlock) {
		this.productlock = productlock;
	}

	public String getImgpath() {
		return imgpath;
	}

	public void setImgpath(String imgpath) {
		this.imgpath = imgpath;
	}

	public double getPrice1() {
		return price1;
	}

	public void setPrice1(double price1) {
		this.price1 = price1;
	}

	public double getPrice2() {
		return price2;
	}

	public void setPrice2(double price2) {
		this.price2 = price2;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	
	@ManyToOne
	@JoinColumn(name="fenleiid")
	public Fenlei getFenlei() {
		return fenlei;
	}

	public void setFenlei(Fenlei fenlei) {
		this.fenlei = fenlei;
	}

	@Column(name="info",columnDefinition="TEXT")
	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public int getXiaoliang() {
		return xiaoliang;
	}

	public void setXiaoliang(int xiaoliang) {
		this.xiaoliang = xiaoliang;
	}

	public int getKucun() {
		return kucun;
	}

	public void setKucun(int kucun) {
		this.kucun = kucun;
	}

	public int getHaoping() {
		return haoping;
	}

	public void setHaoping(int haoping) {
		this.haoping = haoping;
	}

	public int getZhongping() {
		return zhongping;
	}

	public void setZhongping(int zhongping) {
		this.zhongping = zhongping;
	}

	public int getChaping() {
		return chaping;
	}

	public void setChaping(int chaping) {
		this.chaping = chaping;
	}

	public String getXinpingtuijian() {
		return xinpingtuijian;
	}

	public void setXinpingtuijian(String xinpingtuijian) {
		this.xinpingtuijian = xinpingtuijian;
	}

	public String getHot() {
		return hot;
	}

	public void setHot(String hot) {
		this.hot = hot;
	}

	public String getTejiacuxiao() {
		return tejiacuxiao;
	}

	public void setTejiacuxiao(String tejiacuxiao) {
		this.tejiacuxiao = tejiacuxiao;
	}

	public String getTebieytuijian() {
		return tebieytuijian;
	}

	public void setTebieytuijian(String tebieytuijian) {
		this.tebieytuijian = tebieytuijian;
	}

	
	

	

	

	

	
	
	
	
	
}

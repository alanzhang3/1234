package cn.itbaizhan.model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

//系统公告
@Entity
@Table(name="t_Zixun")
public class Zixun implements Serializable{
	
	private static final long serialVersionUID = -117947798302585032L;

	private int id;//主键
	
	private int zixunlock;

	private String title;
	
	private String content;
	

	
	@Id
	@GeneratedValue
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getZixunlock() {
		return zixunlock;
	}

	public void setZixunlock(int zixunlock) {
		this.zixunlock = zixunlock;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	
	

	

	

	

	
	
	
	
	
}

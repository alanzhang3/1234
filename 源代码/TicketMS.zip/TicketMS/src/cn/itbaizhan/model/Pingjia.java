package cn.itbaizhan.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//评价
@Entity
@Table(name="t_Pingjia")
public class Pingjia implements Serializable{
	
	private static final long serialVersionUID = -117947798302585032L;

	private int id;//主键
	
	private int pingjialock;
	
	private Product product;
	
	private User user;
	
	private String pungyu;//评价信息;
	
	private String pingjia;//好评  中评 差评
	
	private Date createtime;
	
	private String pingjiastatus;//未评价 已评价
	
	
	


	
	@Id
	@GeneratedValue
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	



	public int getPingjialock() {
		return pingjialock;
	}

	public void setPingjialock(int pingjialock) {
		this.pingjialock = pingjialock;
	}

	@ManyToOne
	@JoinColumn(name="productid")
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getPungyu() {
		return pungyu;
	}

	public void setPungyu(String pungyu) {
		this.pungyu = pungyu;
	}

	public String getPingjia() {
		return pingjia;
	}

	public void setPingjia(String pingjia) {
		this.pingjia = pingjia;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getPingjiastatus() {
		return pingjiastatus;
	}

	public void setPingjiastatus(String pingjiastatus) {
		this.pingjiastatus = pingjiastatus;
	}

	@ManyToOne
	@JoinColumn(name="userid")
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	

	

	

	

	

	
	
	
	
	
}

package cn.itbaizhan.model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

//彩票分类
@Entity
@Table(name="t_Fenlei")
public class Fenlei implements Serializable{
	
	private static final long serialVersionUID = -117947798302585032L;

	private int id;//主键
	
	private String name;
	
	private int fenleilock;


	
	@Id
	@GeneratedValue
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getFenleilock() {
		return fenleilock;
	}

	public void setFenleilock(int fenleilock) {
		this.fenleilock = fenleilock;
	}

	

	

	

	

	
	
	
	
	
}

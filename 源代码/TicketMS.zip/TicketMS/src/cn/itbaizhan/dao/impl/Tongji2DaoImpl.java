package cn.itbaizhan.dao.impl;
import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import cn.itbaizhan.dao.Tongji2Dao;
import cn.itbaizhan.model.Tongji2;

public class Tongji2DaoImpl extends HibernateDaoSupport implements Tongji2Dao {

	

	public void deleteBean(Tongji2 bean) {
		this.getHibernateTemplate().delete(bean);
		
	}

	public void insertBean(Tongji2 bean) {
		this.getHibernateTemplate().save(bean);
		
	}

	@SuppressWarnings("unchecked")
	public Tongji2 selectBean(String where) {
		List<Tongji2> list = this.getHibernateTemplate().find("from Tongji2 "+where);
		if(list.size()==0){
			return null;
		}
		return list.get(0);
	}

	public long selectBeanCount(final String where) {
		long count = (Long)this.getHibernateTemplate().find(" select count(*) from Tongji2  "+where).get(0);
		return count;
	}

	@SuppressWarnings("unchecked")
	public List<Tongji2> selectBeanList(final int start,final int limit,final String where) {
		return (List<Tongji2>)this.getHibernateTemplate().executeFind(new HibernateCallback(){

			public Object doInHibernate(final Session session) throws HibernateException, SQLException {
				List<Tongji2> list = session.createQuery(" from Tongji2"+where).setFirstResult(start).setMaxResults(limit).list();
				return list;
			}
		});
		
	}

	public void updateBean(Tongji2 bean) {
		this.getHibernateTemplate().update(bean);
		
	}
	
	
	
	
	
	
	
}

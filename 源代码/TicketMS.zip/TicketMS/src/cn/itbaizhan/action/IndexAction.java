package cn.itbaizhan.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import cn.itbaizhan.dao.AddressDao;
import cn.itbaizhan.dao.JiluDao;
import cn.itbaizhan.dao.OrderDao;
import cn.itbaizhan.dao.OrderItemDao;
import cn.itbaizhan.dao.PingjiaDao;
import cn.itbaizhan.dao.ProductDao;
import cn.itbaizhan.dao.UserDao;
import cn.itbaizhan.dao.ZixunDao;
import cn.itbaizhan.model.Address;
import cn.itbaizhan.model.CartItem;
import cn.itbaizhan.model.Jilu;
import cn.itbaizhan.model.Order;
import cn.itbaizhan.model.OrderItem;
import cn.itbaizhan.model.Pingjia;
import cn.itbaizhan.model.Product;
import cn.itbaizhan.model.User;
import cn.itbaizhan.model.Zixun;
import cn.itbaizhan.util.CartService;
import cn.itbaizhan.util.Pager;
import cn.itbaizhan.util.Util;

import com.opensymphony.xwork2.ActionSupport;

public class IndexAction extends ActionSupport {

	private static final long serialVersionUID = 1L;

	private String url = "./";

	public String getUrl() {
		return url;
	}

	private ProductDao productDao;

	public ProductDao getProductDao() {
		return productDao;
	}

	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	
	public void setUrl(String url) {
		this.url = url;
	}
	// 网站首页
	public String index() {
		HttpServletRequest request = ServletActionContext.getRequest();

		// 特别推荐
		request.setAttribute("tebietuijian", productDao.selectBeanList(0, 4,
				" where productlock=0 order by tebieytuijian "));

		// 最新上架
		request.setAttribute("zuixinshangjia", productDao.selectBeanList(0, 5,
				" where productlock=0 order by xinpingtuijian ,id desc"));

		// 热门推荐
		request.setAttribute("rementuijian", productDao.selectBeanList(0, 5,
				" where productlock=0 order by hot "));

		return "success";
	}

	private UserDao userDao;

	public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	// 用户注册操作
	public void register() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String username = request.getParameter("username");
		String address = request.getParameter("address");
		String daan = request.getParameter("daan");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String phone = request.getParameter("phone");
		String qq = request.getParameter("qq");
		String truename = request.getParameter("truename");
		String wenti = request.getParameter("wenti");

		User bean = userDao.selectBean("  where userlock=0 and username='"
				+ username + "'");

		if (bean == null) {
			bean = new User();
			bean.setAddress(address);
			bean.setCreatetime(new Date());
			bean.setDaan(daan);
			bean.setEmail(email);
			bean.setPassword(password);
			bean.setPhone(phone);
			bean.setQq(qq);
			bean.setTruename(truename);
			bean.setUsername(username);
			bean.setWenti(wenti);
			userDao.insertBean(bean);
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('注册成功');window.location.href='index'; </script>");
		} else {
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('用户名已经存在，注册失败！');window.location.href='register.jsp'; </script>");
		}

	}

	// 用户登录操作
	public void login() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		User bean = userDao.selectBean("  where userlock=0 and username='"
				+ username + "' and password='" + password + "'");
		if (bean != null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", bean);
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('登录成功！');window.location.href='index'; </script>");
		} else {
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('用户名或者密码错误！登录失败');window.location.href='index'; </script>");
		}

	}

	// 用户退出操作
	public void loginout() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		HttpSession session = request.getSession();
		session.removeAttribute("user");
		CartService.clear();
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer
				.print("<script  language='javascript'>alert('退出成功！');window.location.href='index'; </script>");

	}

	// 找回密码操作
	public void password() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String daan = request.getParameter("daan");
		String wenti = request.getParameter("wenti");

		User bean = userDao.selectBean("  where userlock=0 and username='"
				+ username + "' and wenti='" + wenti + "' and daan='" + daan
				+ "'");

		if (bean != null) {
			bean.setPassword(password);
			userDao.updateBean(bean);

			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('修改成功');window.location.href='index'; </script>");
		} else {
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('问题或者答案错误，修改失败');window.location.href='index'; </script>");
		}

	}

	// 我的用户信息
	public String userlist() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('请先登录');window.location.href='index'; </script>");
			return null;
		}

		User bean = userDao.selectBean(" where id= " + user.getId());
		request.setAttribute("bean", bean);
		this.setUrl("userlist.jsp");
		return SUCCESS;

	}

	// 跳转到修改个人信息页面
	public String userupdate() {
		HttpServletRequest request = ServletActionContext.getRequest();
		User bean = userDao.selectBean(" where id= "
				+ request.getParameter("id"));
		request.setAttribute("bean", bean);
		this.setUrl("userupdate.jsp");
		return SUCCESS;
	}

	// 修改个人信息操作
	public void userupdate2() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();

		String address = request.getParameter("address");
		String daan = request.getParameter("daan");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String qq = request.getParameter("qq");
		String truename = request.getParameter("truename");
		String wenti = request.getParameter("wenti");

		User bean = userDao.selectBean(" where id= "
				+ request.getParameter("id"));

		bean.setAddress(address);
		bean.setCreatetime(new Date());
		bean.setDaan(daan);
		bean.setEmail(email);
		bean.setPhone(phone);
		bean.setQq(qq);
		bean.setTruename(truename);
		bean.setWenti(wenti);
		userDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer
				.print("<script  language='javascript'>alert('修改成功');window.location.href='indexmethod!userlist'; </script>");

	}
	
	
	// 跳转到修改用户密码页面
	public String passwordupdate() {
		
		this.setUrl("passwordupdate.jsp");
		return SUCCESS;
	}

	// 修改用户密码操作
	public void passwordupdate2() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();

		String password = request.getParameter("password");//原密码
		String password2 = request.getParameter("password2");//新密码
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");

		User bean = userDao.selectBean(" where id= "
				+ user.getId());

		if(bean.getPassword().equals(password)){
			bean.setPassword(password2);
			userDao.updateBean(bean);
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('修改成功');window.location.href='indexmethod!userlist'; </script>");
		}else{
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('修改失败，原密码错误');window.location.href='indexmethod!passwordupdate'; </script>");
		}
		
	}
	
	private ZixunDao zixunDao;
	
	
	public ZixunDao getZixunDao() {
		return zixunDao;
	}

	public void setZixunDao(ZixunDao zixunDao) {
		this.zixunDao = zixunDao;
	}

	// 查看系统公告信息页面
	public String showzixun() {
		HttpServletRequest request = ServletActionContext.getRequest();
		Zixun bean = zixunDao.selectBean(" where id= "
				+ request.getParameter("id"));
		request.setAttribute("title", bean.getTitle());
		request.setAttribute("neirong", bean.getContent());
		this.setUrl("zixun.jsp");
		return SUCCESS;
	}
	
	
//彩票信息列表
public String productlist(){
	HttpServletRequest request = ServletActionContext.getRequest();
	
	String type = request.getParameter("type");
	String name = request.getParameter("name");
	String fenleiid = request.getParameter("fenleiid");

	
	StringBuffer sb = new StringBuffer();
	sb.append(" where ");
	StringBuffer sb2 = new StringBuffer();
	sb2.append(" where ");
	if(name !=null &&!"".equals(name)){
		sb.append(" name like '%"+name+"%' ");
		sb.append(" and ");
		sb2.append(" name like '%"+name+"%' ");
		sb2.append(" and ");
		request.setAttribute("name", name);
	}
	
	if(fenleiid !=null &&!"".equals(fenleiid)){
		sb.append(" fenlei.id=  "+fenleiid);
		sb.append(" and ");
		sb2.append(" fenlei.id=  "+fenleiid);
		sb2.append(" and ");
		request.setAttribute("fenleiid", fenleiid);
	}
	
	if("1".equals(type)){//新品推荐排序
		
		sb.append(" productlock=0 order by xinpingtuijian ,  id desc ");
	}else if("2".equals(type)){//热销推荐排序
		sb.append(" productlock=0 order by hot ,  id desc ");
	}else if("3".equals(type)){//特价促销排序
		sb.append(" productlock=0 order by tejiacuxiao , id desc ");
	}else if("4".equals(type)){//特别推荐排序
		sb.append(" productlock=0 order by tebieytuijian ,  id desc ");
	}
	else if("5".equals(type)){//销量排序
		sb.append(" productlock=0 order by xiaoliang desc ,  id desc ");
	}
	else if("6".equals(type)){//优惠幅度排序
		sb.append(" productlock=0   and price3 !=0 order by tejiacuxiao , price3 desc ,  id desc  ");
	}
	else if("7".equals(type)){//新品排序
		sb.append("  productlock=0 order by xinpingtuijian ,id desc ");
	}else{
		sb.append(" productlock=0 order by id desc  ");
	}
	sb2.append(" productlock=0 ");
	String where = sb.toString();
	String where2 = sb2.toString();
	
	

	int currentpage = 1;
	int pagesize = 6;
	if(request.getParameter("pagenum") != null){
		currentpage = Integer.parseInt(request.getParameter("pagenum"));
	}
	
	long total = productDao.selectBeanCount(where2);
	List<Product> list = productDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
	request.setAttribute("list", list);
	String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "indexmethod!productlist?fenleiid="+fenleiid, "共有"+total+"条记录");
	request.setAttribute("pagerinfo", pagerinfo);
	this.setUrl("productlist.jsp");
	return SUCCESS;
}
	
	
	// 查看彩票信息页面
	public String showproduct() {
		HttpServletRequest request = ServletActionContext.getRequest();
		Product bean = productDao.selectBean(" where id= "
				+ request.getParameter("id"));
		request.setAttribute("bean", bean);
		//推荐关联彩票
		List<Product> list = new ArrayList<Product>();
		
		
		Jilu jilu =jiluDao.selectBean(" where product.id= "+bean.getId());
		if(jilu==null){
			jilu = new Jilu();
			jilu.setProduct(bean);
			jiluDao.insertBean(jilu);
		}
		String guanlian = jilu.getGuanlian();
		if(guanlian!=null){
			String[] s = guanlian.split(",");
			for(int i=0;i<s.length;i++){
				if(s[i]!=null &&!"".equals(s[i])){
					Product p = productDao.selectBean(" where id= "+s[i]);
					list.add(p);
				}
				
			}
		}else{
			list = productDao.selectBeanList(0, 9999, " where fenlei.id= "+bean.getFenlei().getId() +" and id!="+bean.getId());
		}
		List<Product> list2 = new ArrayList<Product>();
		Set<Product> set = new HashSet<Product>();
		
		//去掉重复的关联彩票
		for(Product p:list){
			set.add(p);
		}
		
		for(Product p :set){
			list2.add(p);
		}
		
		request.setAttribute("productlist", IndexAction.suiji(list2, 3));
		
		
		
		this.setUrl("product.jsp");
		return SUCCESS;
	}
	
	//随即取list彩票的数量
	private static List<Product> suiji(List<Product> list,int num){
		Collections.shuffle(list);
		List<Product> list2 = new ArrayList<Product>();
		if(list.size()<=num){
			num = list.size();
		}
		for(int i=0;i<num;i++){
			list2.add(list.get(i));
		}
		return list2;
	}
	
	
	// 添加彩票到彩票预定车操作
	public void cartadd() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();

		Product product = productDao.selectBean(" where id= "+request.getParameter("pid"));
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('请先登录');window.location.href='index'; </script>");
			return ;
		}
		
		if(CartService.addItem(product)){
			
			int num = Integer.parseInt(request.getParameter("num"));
			if(num>product.getKucun()){
				response.setCharacterEncoding("gbk");
				PrintWriter writer = response.getWriter();
				writer
						.print("<script  language='javascript'>alert('购买数量大于彩票的库存数量，以添加一件彩票到彩票预定车');window.location.href='indexmethod!cartlist'; </script>");
				return;
			}
			CartService.updateNum((int)product.getId(), num);
			
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('添加成功');window.location.href='indexmethod!showproduct?id="+product.getId()+"'; </script>");
		}else{
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('添加失败，该彩票已经在彩票预定车里面存在！');window.location.href='indexmethod!showproduct?id="+product.getId()+"'; </script>");
		}
		
	}
	
	
	//彩票预定车列表
	public String cartlist() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();

		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('请先登录');window.location.href='index'; </script>");
			return null;
		}
		request.setAttribute("cartItems", CartService.getItems());
		request.setAttribute("dropcartItems", CartService.getDropItems());
		request.setAttribute("price1", CartService.getPrice1());
		request.setAttribute("price2", CartService.getPrice2());
		request.setAttribute("price1-price2", CartService.getPrice1()-CartService.getPrice2());
		this.setUrl("cartlist.jsp");
		return SUCCESS;
	}
	

	
	// 修改彩票预定车的彩票数量操作
	public void cartchangenum() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();

		Product product = productDao.selectBean(" where id= "+request.getParameter("pid"));
		int num = Integer.parseInt(request.getParameter("num"));
		if(num>product.getKucun()){
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('变更失败，购买数量大于彩票的库存数量');window.location.href='indexmethod!cartlist'; </script>");
			return;
		}
		CartService.updateNum((int)product.getId(), num);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer
				.print("<script  language='javascript'>alert('变更成功');window.location.href='indexmethod!cartlist'; </script>");

	}
	
	
	// 删除彩票预定车的彩票操作
	public void delproduct() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		CartService.drop(Integer.parseInt(request.getParameter("pid")));
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer
				.print("<script  language='javascript'>alert('删除成功');window.location.href='indexmethod!cartlist'; </script>");

	}
	
	
	// 恢复彩票预定车的彩票操作
	public void recoveryCart() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		CartService.recovery(Integer.parseInt(request.getParameter("pid")));
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer
				.print("<script  language='javascript'>alert('恢复成功');window.location.href='indexmethod!cartlist'; </script>");

	}
	
	private AddressDao addressDao;

	public AddressDao getAddressDao() {
		return addressDao;
	}

	public void setAddressDao(AddressDao addressDao) {
		this.addressDao = addressDao;
	}
	
	//我的送票地址信息列表
	public String addresslist() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('请先登录');window.location.href='index'; </script>");
			return null;
		}
		

		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		
		
		sb.append(" addresslock=0 and user.id="+user.getId()+" order by id desc ");
		sb2.append(" addresslock=0 and user.id="+user.getId());
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = addressDao.selectBeanCount(where2);
		List<Address> list = addressDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!addresslist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		this.setUrl("addresslist.jsp");
		return SUCCESS;
	}
	
	//跳转到添加我的送票地址页面
	public String addressadd(){
		this.setUrl("addressadd.jsp");
		return SUCCESS;
	}
	
	
	//添加我的送票地址操作
	public void addressadd2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String dizhi = request.getParameter("dizhi");
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		Address bean = new Address();
		bean.setDizhi(dizhi);
		bean.setUser(user);
		addressDao.insertBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('操作成功');window.location.href='indexmethod!addresslist'; </script>");
		
	}
	
	//删除我的送票地址操作
	public void addressdelete() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String id = request.getParameter("id");
		Address bean =addressDao.selectBean(" where id= "+id);
		bean.setAddresslock(1);
		addressDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('操作成功');window.location.href='indexmethod!addresslist'; </script>");
		
	}
	
	//跳转到更新我的送票地址页面
	public String addressupdate(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String id = request.getParameter("id");
		Address bean =addressDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("addressupdate.jsp");
		return SUCCESS;
	}
	
	
	//更新我的送票地址操作
	public void addressupdate2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String dizhi = request.getParameter("dizhi");
		String id = request.getParameter("id");
		Address bean =addressDao.selectBean(" where id= "+id);
		bean.setDizhi(dizhi);
		addressDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('操作成功');window.location.href='indexmethod!addresslist'; </script>");
		
	}
	
	private OrderItemDao orderItemDao;
	
	private OrderDao orderDao;

	public OrderItemDao getOrderItemDao() {
		return orderItemDao;
	}

	public void setOrderItemDao(OrderItemDao orderItemDao) {
		this.orderItemDao = orderItemDao;
	}

	public OrderDao getOrderDao() {
		return orderDao;
	}

	public void setOrderDao(OrderDao orderDao) {
		this.orderDao = orderDao;
	}
	
	//跳转到填写订单收货地址信息页面
	public String jiesuan() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('请先登录');window.location.href='index'; </script>");
			return null;
		}
		List<CartItem> cartItems = CartService.getItems();
		
		if(cartItems.isEmpty()){
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('该彩票预定车为空，无法生成订单');window.location.href='indexmethod!cartlist'; </script>");
			return null;
		}
		
		for(CartItem ci:cartItems){
			Product product = productDao.selectBean(" where id= "+ci.getProduct().getId());
			if(ci.getNumber()>product.getKucun()){
				response.setCharacterEncoding("gbk");
				PrintWriter writer = response.getWriter();
				writer
						.print("<script  language='javascript'>alert('您购买的"+product.getName()+"的数量超过该彩票的库存量，结算失败');window.location.href='indexmethod!cartlist'; </script>");
				return null;
			}
		}
		
		request.setAttribute("addresslist", addressDao.selectBeanList(0, 9999, " where  addresslock=0 and  user.id= "+user.getId()));
		
		this.setUrl("jiesuan.jsp");
		return SUCCESS;
	}
	
	
	//生成订单操作
	public void createorder() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('请先登录');window.location.href='index'; </script>");
			return ;
		}
		//获取彩票预定车的彩票信息
		List<CartItem> cartItems = CartService.getItems();
		List<OrderItem> orderItems = new ArrayList<OrderItem>();
		//把彩票预定车的购物的彩票信息存入订单条目中
		for(CartItem ci:cartItems){
			Product product = productDao.selectBean(" where id= "+ci.getProduct().getId());
			OrderItem oi = new OrderItem();
			oi.setProduct(product);
			oi.setPrice(ci.getProduct().getPrice2());
			oi.setProductname(ci.getProduct().getName());
			oi.setProductnum(ci.getNumber());
			orderItems.add(oi);
			product.setXiaoliang(product.getXiaoliang()+ci.getNumber());
			product.setKucun(product.getKucun()-ci.getNumber());
			productDao.updateBean(product);
			
			//该彩票关联的彩票信息
			Jilu j = jiluDao.selectBean(" where product.id= "+product.getId() );
			if(j==null){
				j = new Jilu();
				j.setProduct(product);
				jiluDao.insertBean(j);
			}
			StringBuffer sb = new StringBuffer();
			for(CartItem ccc:cartItems){
				if(product.getId()!= ccc.getProduct().getId()){
					sb.append(ccc.getProduct().getId());
					sb.append(",");
				}
				
			}
			
			if(j.getGuanlian()!=null){
				j.setGuanlian(j.getGuanlian()+sb.toString());
			}else{
				j.setGuanlian(sb.toString());
			}
			
			jiluDao.updateBean(j);
			
			
			
		}
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		String username = request.getParameter("username");
		String shsj = request.getParameter("shsj");
		Order order = new Order();
		order.setAddress(address);
		order.setCreatetime(new Date());
		order.setOrderid(Util.getTime2());
		order.setPhone(phone);
		order.setStatus("未发货");
		order.setTotalprice(CartService.getPrice2());
		order.setUser(user);
		order.setUsername(username);
		order.setShsj(shsj);
		orderDao.insertBean(order);
		for(OrderItem oi: orderItems){
			oi.setOrder(order);
			orderItemDao.insertBean(oi);
		}
		CartService.clear();
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer
				.print("<script  language='javascript'>alert('订单生成成功，请密切关注订单的状态');window.location.href='indexmethod!orderlist'; </script>");
		
	}
	
	
	//我的订单信息列表
	public String orderlist() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('请先登录');window.location.href='index'; </script>");
			return null ;
		}
		
		String orderid = request.getParameter("orderid");
		String status = request.getParameter("status");
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		if(orderid !=null &&!"".equals(orderid)){
			sb.append(" orderid like '%"+orderid+"%' ");
			sb.append(" and ");
			sb2.append(" orderid like '%"+orderid+"%' ");
			sb2.append(" and ");
			request.setAttribute("orderid", orderid);
		}
		
		if(status !=null &&!"".equals(status)){
			sb.append(" status like '%"+status+"%' ");
			sb.append(" and ");
			sb2.append(" status like '%"+status+"%' ");
			sb2.append(" and ");
			request.setAttribute("status", status);
		}
		
		sb.append(" user.id="+user.getId()+" order by id desc ");
		sb2.append(" user.id="+user.getId());
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = orderDao.selectBeanCount(where2);
		List<Order> list = orderDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!orderlist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		this.setUrl("orderlist.jsp");
		return SUCCESS;
	}
	
	//查看订单详情
	public String order(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String id = request.getParameter("id");
		Order bean =orderDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		request.setAttribute("list", orderItemDao.selectBeanList(0, 9999, " where order.id= "+bean.getId()));
		this.setUrl("order.jsp");
		return SUCCESS;
	}
	
	
	private PingjiaDao pingjiaDao;
	
	public PingjiaDao getPingjiaDao() {
		return pingjiaDao;
	}

	public void setPingjiaDao(PingjiaDao pingjiaDao) {
		this.pingjiaDao = pingjiaDao;
	}

	//我的评价评价信息列表
	public String pingjialist() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer
					.print("<script  language='javascript'>alert('请先登录');window.location.href='index'; </script>");
			return null ;
		}
		
		String pingjiastatus = request.getParameter("pingjiastatus");
		String pingjia = request.getParameter("pingjia");
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		if(pingjiastatus !=null &&!"".equals(pingjiastatus)){
			sb.append(" pingjiastatus like '%"+pingjiastatus+"%' ");
			sb.append(" and ");
			sb2.append(" pingjiastatus like '%"+pingjiastatus+"%' ");
			sb2.append(" and ");
			request.setAttribute("pingjiastatus", pingjiastatus);
		}
		
		if(pingjia !=null &&!"".equals(pingjia)){
			sb.append(" pingjia like '%"+pingjia+"%' ");
			sb.append(" and ");
			sb2.append(" pingjia like '%"+pingjia+"%' ");
			sb2.append(" and ");
			request.setAttribute("pingjia", pingjia);
		}
		
		sb.append(" user.id="+user.getId()+" order by id desc ");
		sb2.append(" user.id="+user.getId());
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = pingjiaDao.selectBeanCount(where2);
		List<Pingjia> list = pingjiaDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!pingjialist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		this.setUrl("pingjialist.jsp");
		return SUCCESS;
	}
	
	
	//跳转到填写评价信息页面
	public String pingjiaupdate(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String id = request.getParameter("id");
		Pingjia bean =pingjiaDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("pingjiaupdate.jsp");
		return SUCCESS;
	}
	
	
	//评价操作
	public void pingjiaupdate2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String pingjia = request.getParameter("pingjia");
		String pungyu = request.getParameter("pungyu");
		String id = request.getParameter("id");
		Pingjia bean =pingjiaDao.selectBean(" where id= "+id);
		bean.setPingjia(pingjia);
		bean.setPungyu(pungyu);
		bean.setPingjiastatus("已评价");
		bean.setCreatetime(new Date());

		pingjiaDao.updateBean(bean);
		
		Product p = bean.getProduct();
		p.setPingjiashuliang(p.getPingjiashuliang()+1);
		if("好评".equals(pingjia)){
			p.setHaoping(p.getHaoping()+1);
		}else if("中评".equals(pingjia)){
			p.setZhongping(p.getZhongping()+1);
		}else if("差评".equals(pingjia)){
			p.setChaping(p.getChaping()+1);
		}
		
		productDao.updateBean(p);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('操作成功');window.location.href='indexmethod!pingjialist'; </script>");
		
	}
	
	//跳转到查看评价信息页面
	public String pingjiaupdate3(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String id = request.getParameter("id");
		Pingjia bean =pingjiaDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("pingjiaupdate3.jsp");
		return SUCCESS;
	}
	
	
	//评价列表
	public String pingjialist2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();

		
		
		String pingjiastatus = request.getParameter("pingjiastatus");
		String pingjia = request.getParameter("pingjia");
		String pid = request.getParameter("pid");
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		if(pid !=null &&!"".equals(pid)){
			sb.append(" product.id= "+pid );
			sb.append(" and ");
			sb2.append(" product.id= "+pid );
			sb2.append(" and ");
			request.setAttribute("pid", pid);
		}
		
		if(pingjiastatus !=null &&!"".equals(pingjiastatus)){
			sb.append(" pingjiastatus like '%"+pingjiastatus+"%' ");
			sb.append(" and ");
			sb2.append(" pingjiastatus like '%"+pingjiastatus+"%' ");
			sb2.append(" and ");
			request.setAttribute("pingjiastatus", pingjiastatus);
		}
		
		if(pingjia !=null &&!"".equals(pingjia)){
			sb.append(" pingjia like '%"+pingjia+"%' ");
			sb.append(" and ");
			sb2.append(" pingjia like '%"+pingjia+"%' ");
			sb2.append(" and ");
			request.setAttribute("pingjia", pingjia);
		}
		
		sb.append(" 1=1 order by id desc ");
		sb2.append(" 1=1 ");
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = pingjiaDao.selectBeanCount(where2);
		List<Pingjia> list = pingjiaDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!pingjialist2", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		this.setUrl("pingjialist2.jsp");
		return SUCCESS;
	}
	
	private JiluDao jiluDao;

	public JiluDao getJiluDao() {
		return jiluDao;
	}

	public void setJiluDao(JiluDao jiluDao) {
		this.jiluDao = jiluDao;
	}
	

}

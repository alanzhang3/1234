package cn.itbaizhan.action;




import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import cn.itbaizhan.dao.FenleiDao;
import cn.itbaizhan.dao.ManageDao;
import cn.itbaizhan.dao.OrderDao;
import cn.itbaizhan.dao.OrderItemDao;
import cn.itbaizhan.dao.PingjiaDao;
import cn.itbaizhan.dao.ProductDao;
import cn.itbaizhan.dao.Tongji2Dao;
import cn.itbaizhan.dao.TongjiDao;
import cn.itbaizhan.dao.UserDao;
import cn.itbaizhan.dao.ZixunDao;
import cn.itbaizhan.model.Fenlei;
import cn.itbaizhan.model.Manage;
import cn.itbaizhan.model.Order;
import cn.itbaizhan.model.OrderItem;
import cn.itbaizhan.model.Pingjia;
import cn.itbaizhan.model.Product;
import cn.itbaizhan.model.Tongji;
import cn.itbaizhan.model.Tongji2;
import cn.itbaizhan.model.User;
import cn.itbaizhan.model.Zixun;
import cn.itbaizhan.util.Pager;
import cn.itbaizhan.util.Util;

import com.opensymphony.xwork2.ActionSupport;


public class ManageAction extends ActionSupport{

	
	private static final long serialVersionUID = 1L;
	
	
	private String url="./";
	
	
	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}
	
	private ManageDao manageDao;


	public ManageDao getManageDao() {
		return manageDao;
	}


	public void setManageDao(ManageDao manageDao) {
		this.manageDao = manageDao;
	}
	
	
	public void login() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		Manage bean = manageDao.selectBean(" where username='"+username+"' and password ='"+password+"' ");
		if(bean!=null){
			HttpSession session = request.getSession();
			session.setAttribute("manage", bean);
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('登陆成功');window.location.href='default.jsp'; </script>");
		}else{
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('用户名或者密码错误');window.location.href='login.jsp'; </script>");
		}
		
		
	}
	
	//用户退出操作
	public void loginout() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		session.removeAttribute("manage");
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('退出成功');window.location.href='login.jsp'; </script>");
	}
	
	
	public String passwordupdate(){
		this.setUrl("password.jsp");
		return SUCCESS;
		
	}
	
	
	
	public void passwordupdate2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String password1 = request.getParameter("password1");
		String password2 = request.getParameter("password2");
		HttpSession session = request.getSession();
		Manage user = (Manage)session.getAttribute("manage");
		
		Manage bean = manageDao.selectBean(" where username='"+user.getUsername()+"' and password ='"+password1+"' ");
		if(bean!=null){
			bean.setPassword(password2);
			manageDao.updateBean(bean);
			
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('success!');</script>");
		}else{
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('原密码错误');window.location.href='method!passwordupdate'; </script>");
		}
		
		
	}
	
	private FenleiDao fenleiDao;


	public FenleiDao getFenleiDao() {
		return fenleiDao;
	}


	public void setFenleiDao(FenleiDao fenleiDao) {
		this.fenleiDao = fenleiDao;
	}
	
	
	//彩票分类信息列表
	public String fenleilist(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String name = request.getParameter("name");
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		if(name !=null &&!"".equals(name)){
			sb.append(" name like '%"+name+"%' ");
			sb.append(" and ");
			sb2.append(" name like '%"+name+"%' ");
			sb2.append(" and ");
			request.setAttribute("name", name);
		}
		
		sb.append(" fenleilock=0 order by id desc ");
		sb2.append(" fenleilock=0 ");
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = fenleiDao.selectBeanCount(where2);
		List<Fenlei> list = fenleiDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!fenleilist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		request.setAttribute("url", "method!fenleilist");
		request.setAttribute("url2", "method!fenlei");
		request.setAttribute("titletitle", "彩票分类信息管理");
		this.setUrl("fenlei/fenleilist.jsp");
		return SUCCESS;
	}
	
	
	//跳转到添加彩票分类页面
	public String fenleiadd(){
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setAttribute("url", "method!fenleiadd2");
		request.setAttribute("titletitle", "添加彩票分类信息");
		this.setUrl("fenlei/fenleiadd.jsp");
		return SUCCESS;
	}
	
	
	//添加彩票分类操作
	public void fenleiadd2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String name = request.getParameter("name");
		Fenlei bean = new Fenlei();
		bean.setName(name);
		fenleiDao.insertBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!fenleilist'; </script>");
		
	}
	
	
	
	//删除彩票分类操作
	public void fenleidelete() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String id = request.getParameter("id");
		Fenlei bean =fenleiDao.selectBean(" where id= "+id);
		bean.setFenleilock(1);
		fenleiDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!fenleilist'; </script>");
		
	}
	
	//跳转到更新彩票分类页面
	public String fenleiupdate(){
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setAttribute("url", "method!fenleiupdate2");
		request.setAttribute("titletitle", "修改彩票分类信息");
		String id = request.getParameter("id");
		Fenlei bean =fenleiDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("fenlei/fenleiupdate.jsp");
		return SUCCESS;
	}
	
	
	//更新彩票分类操作
	public void fenleiupdate2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String name = request.getParameter("name");
		String id = request.getParameter("id");
		Fenlei bean =fenleiDao.selectBean(" where id= "+id);
		bean.setName(name);
		fenleiDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!fenleilist'; </script>");
		
	}
	
	//跳转到查看彩票分类页面
	public String fenleiupdate3(){
		HttpServletRequest request = ServletActionContext.getRequest();

		request.setAttribute("titletitle", "查看彩票分类信息");
		String id = request.getParameter("id");
		Fenlei bean =fenleiDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("fenlei/fenleiupdate3.jsp");
		return SUCCESS;
	}
	
	
	private ProductDao productDao;


	public ProductDao getProductDao() {
		return productDao;
	}


	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}
	
	
	//彩票信息列表
	public String productlist(){
		HttpServletRequest request = ServletActionContext.getRequest();
		
		String name = request.getParameter("name");
		String fenlei = request.getParameter("fenlei");
		request.setAttribute("fenleilist", fenleiDao.selectBeanList(0, 9999, " where  fenleilock=0 "));
		
		String xinpingtuijian = request.getParameter("xinpingtuijian");
		String hot = request.getParameter("hot");
		String tejiacuxiao = request.getParameter("tejiacuxiao");
		String tebieytuijian = request.getParameter("tebieytuijian");
		
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		if(name !=null &&!"".equals(name)){
			sb.append(" name like '%"+name+"%' ");
			sb.append(" and ");
			sb2.append(" name like '%"+name+"%' ");
			sb2.append(" and ");
			request.setAttribute("name", name);
		}
		
		if(fenlei !=null &&!"".equals(fenlei)){
			sb.append(" fenlei.name like '%"+fenlei+"%' ");
			sb.append(" and ");
			sb2.append(" fenlei.name like '%"+fenlei+"%' ");
			sb2.append(" and ");
			request.setAttribute("fenlei", fenlei);
		}
		
		if(xinpingtuijian !=null &&!"".equals(xinpingtuijian)){
			sb.append(" xinpingtuijian like '%"+xinpingtuijian+"%' ");
			sb.append(" and ");
			sb2.append(" xinpingtuijian like '%"+xinpingtuijian+"%' ");
			sb2.append(" and ");
			request.setAttribute("xinpingtuijian", xinpingtuijian);
		}
		
		if(hot !=null &&!"".equals(hot)){
			sb.append(" hot like '%"+hot+"%' ");
			sb.append(" and ");
			sb2.append(" hot like '%"+hot+"%' ");
			sb2.append(" and ");
			request.setAttribute("hot", hot);
		}
		
		if(tejiacuxiao !=null &&!"".equals(tejiacuxiao)){
			sb.append(" tejiacuxiao like '%"+tejiacuxiao+"%' ");
			sb.append(" and ");
			sb2.append(" tejiacuxiao like '%"+tejiacuxiao+"%' ");
			sb2.append(" and ");
			request.setAttribute("tejiacuxiao", tejiacuxiao);
		}
		
		if(tebieytuijian !=null &&!"".equals(tebieytuijian)){
			sb.append(" tebieytuijian like '%"+tebieytuijian+"%' ");
			sb.append(" and ");
			sb2.append(" tebieytuijian like '%"+tebieytuijian+"%' ");
			sb2.append(" and ");
			request.setAttribute("tebieytuijian", tebieytuijian);
		}
		
		sb.append(" productlock=0 order by id desc ");
		sb2.append(" productlock=0 ");
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = productDao.selectBeanCount(where2);
		List<Product> list = productDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!productlist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		request.setAttribute("url", "method!productlist");
		request.setAttribute("url2", "method!product");
		request.setAttribute("titletitle", "彩票信息管理");
		this.setUrl("product/productlist.jsp");
		return SUCCESS;
	}
	
	
	//跳转到添加彩票页面
	public String productadd(){
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setAttribute("fenleilist", fenleiDao.selectBeanList(0, 9999, " where  fenleilock=0 "));
		request.setAttribute("url", "method!productadd2");
		request.setAttribute("titletitle", "添加彩票信息");
		this.setUrl("product/productadd.jsp");
		return SUCCESS;
	}
	
	
	private File uploadfile;
	
	
	public File getUploadfile() {
		return uploadfile;
	}


	public void setUploadfile(File uploadfile) {
		this.uploadfile = uploadfile;
	}


	//添加彩票操作
	public void productadd2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String name = request.getParameter("name");
		String fenlei = request.getParameter("fenlei");
		String info = request.getParameter("info");
		String kucun = request.getParameter("kucun");
		String price1 = request.getParameter("price1");
		String price2 = request.getParameter("price2");
		String savapath = ServletActionContext.getServletContext().getRealPath("/")+"/productimg/";
		String time = Util.getTime2();
		String imgpath = time+".jpg";
		File file = new File(savapath+imgpath);
		Util.copyFile(uploadfile, file);
		
		Product bean = new Product();
		bean.setCreatetime(new Date());
		bean.setFenlei(fenleiDao.selectBean(" where id= "+fenlei));
		bean.setHot("未推荐");
		bean.setImgpath(imgpath);
		bean.setInfo(info);
		bean.setKucun(Integer.parseInt(kucun));
		bean.setName(name);
		bean.setPrice1(Double.parseDouble(price1));
		bean.setPrice2(Double.parseDouble(price2));
		bean.setTebieytuijian("未推荐");
		bean.setTejiacuxiao("未推荐");
		bean.setXinpingtuijian("已推荐");
		bean.setPrice3(bean.getPrice1()-bean.getPrice2());
		bean.setName(name);
		productDao.insertBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!productlist'; </script>");
		
	}
	
	
	
	//删除彩票操作
	public void productdelete() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String id = request.getParameter("id");
		Product bean =productDao.selectBean(" where id= "+id);
		bean.setProductlock(1);
		productDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!productlist'; </script>");
		
	}
	
	//跳转到更新彩票页面
	public String productupdate(){
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setAttribute("fenleilist", fenleiDao.selectBeanList(0, 9999, " where  fenleilock=0 "));
		request.setAttribute("url", "method!productupdate2");
		request.setAttribute("titletitle", "修改彩票信息");
		String id = request.getParameter("id");
		Product bean =productDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("product/productupdate.jsp");
		return SUCCESS;
	}
	
	
	//更新彩票操作
	public void productupdate2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String name = request.getParameter("name");
		String fenlei = request.getParameter("fenlei");
		String info = request.getParameter("info");
		String price1 = request.getParameter("price1");
		String price2 = request.getParameter("price2");
		String id = request.getParameter("id");
		Product bean =productDao.selectBean(" where id= "+id);
		String shangchuan = request.getParameter("shangchuan");
		if(!"1".equals(shangchuan)){
			String savapath = ServletActionContext.getServletContext().getRealPath("/")+"/productimg/";
			String time = Util.getTime2();
			String imgpath = time+".jpg";
			File file = new File(savapath+imgpath);
			Util.copyFile(uploadfile, file);
			bean.setImgpath(imgpath);
		}
		bean.setCreatetime(new Date());
		bean.setFenlei(fenleiDao.selectBean(" where id= "+fenlei));
		bean.setInfo(info);
		bean.setName(name);
		bean.setPrice1(Double.parseDouble(price1));
		bean.setPrice2(Double.parseDouble(price2));
		bean.setPrice3(bean.getPrice1()-bean.getPrice2());
		productDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!productlist'; </script>");
		
	}
	
	//跳转到查看彩票页面
	public String productupdate3(){
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setAttribute("titletitle", "查看彩票信息");
		String id = request.getParameter("id");
		Product bean =productDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("product/productupdate3.jsp");
		return SUCCESS;
	}
	

	
	//跳转到彩票入库页面
	public String productupdate5(){
		HttpServletRequest request = ServletActionContext.getRequest();

		request.setAttribute("url", "method!productupdate6");
		request.setAttribute("titletitle", "彩票入库");
		String id = request.getParameter("id");
		Product bean =productDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("product/productupdate5.jsp");
		return SUCCESS;
	}
	
	
	//彩票入库操作
	public void productupdate6() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String kucun = request.getParameter("kucun");
		String id = request.getParameter("id");
	
		Product bean =productDao.selectBean(" where id= "+id);
		bean.setKucun(Integer.parseInt(kucun)+bean.getKucun());
		productDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!productlist'; </script>");
		
	}
	
	//新品推荐操作
	public void productdelete2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String id = request.getParameter("id");
		Product bean =productDao.selectBean(" where id= "+id);
		if("未推荐".equals(bean.getXinpingtuijian())){
			bean.setXinpingtuijian("已推荐");
		}else{
			bean.setXinpingtuijian("未推荐");
		}
		productDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!productlist'; </script>");
		
	}
	
	//热销推荐操作
	public void productdelete3() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String id = request.getParameter("id");
		Product bean =productDao.selectBean(" where id= "+id);
		if("未推荐".equals(bean.getHot())){
			bean.setHot("已推荐");
		}else{
			bean.setHot("未推荐");
		}
		productDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!productlist'; </script>");
		
	}
	
	//特价促销操作
	public void productdelete4() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String id = request.getParameter("id");
		Product bean =productDao.selectBean(" where id= "+id);
		if("未推荐".equals(bean.getTejiacuxiao())){
			bean.setTejiacuxiao("已推荐");
		}else{
			bean.setTejiacuxiao("未推荐");
		}
		productDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!productlist'; </script>");
		
	}
	
	//特别推荐操作
	public void productdelete5() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String id = request.getParameter("id");
		Product bean =productDao.selectBean(" where id= "+id);
		if("未推荐".equals(bean.getTebieytuijian())){
			bean.setTebieytuijian("已推荐");
		}else{
			bean.setTebieytuijian("未推荐");
		}
		productDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!productlist'; </script>");
		
	}
	
	private ZixunDao zixunDao;


	public ZixunDao getZixunDao() {
		return zixunDao;
	}


	public void setZixunDao(ZixunDao zixunDao) {
		this.zixunDao = zixunDao;
	}
	
	//系统公告信息列表
	public String zixunlist(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String title = request.getParameter("title");
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		if(title !=null &&!"".equals(title)){
			sb.append(" title like '%"+title+"%' ");
			sb.append(" and ");
			sb2.append(" title like '%"+title+"%' ");
			sb2.append(" and ");
			request.setAttribute("title", title);
		}
		
		sb.append(" zixunlock=0 order by id desc ");
		sb2.append(" zixunlock=0 ");
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = zixunDao.selectBeanCount(where2);
		List<Zixun> list = zixunDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!zixunlist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		request.setAttribute("url", "method!zixunlist");
		request.setAttribute("url2", "method!zixun");
		request.setAttribute("titletitle", "系统公告信息管理");
		this.setUrl("zixun/zixunlist.jsp");
		return SUCCESS;
	}
	
	
	//跳转到添加系统公告页面
	public String zixunadd(){
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setAttribute("url", "method!zixunadd2");
		request.setAttribute("titletitle", "添加系统公告信息");
		this.setUrl("zixun/zixunadd.jsp");
		return SUCCESS;
	}
	
	
	//添加系统公告操作
	public void zixunadd2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String content = request.getParameter("content");
		String title = request.getParameter("title");
		Zixun bean = new Zixun();
		bean.setContent(content);
		bean.setTitle(title);
		zixunDao.insertBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!zixunlist'; </script>");
		
	}
	
	
	
	//删除系统公告操作
	public void zixundelete() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String id = request.getParameter("id");
		Zixun bean =zixunDao.selectBean(" where id= "+id);
		bean.setZixunlock(1);
		zixunDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!zixunlist'; </script>");
		
	}
	
	//跳转到更新系统公告页面
	public String zixunupdate(){
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setAttribute("url", "method!zixunupdate2");
		request.setAttribute("titletitle", "修改系统公告信息");
		String id = request.getParameter("id");
		Zixun bean =zixunDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("zixun/zixunupdate.jsp");
		return SUCCESS;
	}
	
	
	//更新系统公告操作
	public void zixunupdate2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String content = request.getParameter("content");
		String title = request.getParameter("title");
		String id = request.getParameter("id");
		Zixun bean =zixunDao.selectBean(" where id= "+id);
		bean.setContent(content);
		bean.setTitle(title);
		zixunDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!zixunlist'; </script>");
		
	}
	
	//跳转到查看系统公告页面
	public String zixunupdate3(){
		HttpServletRequest request = ServletActionContext.getRequest();

		request.setAttribute("titletitle", "查看系统公告信息");
		String id = request.getParameter("id");
		Zixun bean =zixunDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("zixun/zixunupdate3.jsp");
		return SUCCESS;
	}

	private OrderDao orderDao;
	
	
	public OrderDao getOrderDao() {
		return orderDao;
	}


	public void setOrderDao(OrderDao orderDao) {
		this.orderDao = orderDao;
	}
	
	private OrderItemDao orderItemDao;
	


	public OrderItemDao getOrderItemDao() {
		return orderItemDao;
	}


	public void setOrderItemDao(OrderItemDao orderItemDao) {
		this.orderItemDao = orderItemDao;
	}


	//订单信息列表
	public String orderlist(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String orderid = request.getParameter("orderid");
		String username = request.getParameter("username");
		String status = request.getParameter("status");
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		if(orderid !=null &&!"".equals(orderid)){
			sb.append(" orderid like '%"+orderid+"%' ");
			sb.append(" and ");
			sb2.append(" orderid like '%"+orderid+"%' ");
			sb2.append(" and ");
			request.setAttribute("orderid", orderid);
		}
		
		if(username !=null &&!"".equals(username)){
			sb.append(" username like '%"+username+"%' ");
			sb.append(" and ");
			sb2.append(" username like '%"+username+"%' ");
			sb2.append(" and ");
			request.setAttribute("username", username);
		}
		
		if(status !=null &&!"".equals(status)){
			sb.append(" status like '%"+status+"%' ");
			sb.append(" and ");
			sb2.append(" status like '%"+status+"%' ");
			sb2.append(" and ");
			request.setAttribute("status", status);
		}
		
		sb.append(" 1=1 order by status desc ");
		sb2.append(" 1=1 ");
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = orderDao.selectBeanCount(where2);
		List<Order> list = orderDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!orderlist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		request.setAttribute("url", "method!orderlist");
		request.setAttribute("url2", "method!order");
		request.setAttribute("titletitle", "订单信息管理");
		this.setUrl("order/orderlist.jsp");
		return SUCCESS;
	}
	
	
	//发货操作
	public void orderdelete() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		Order bean = orderDao.selectBean(" where id= "+request.getParameter("id"));
		bean.setStatus("已发货");
		orderDao.updateBean(bean);
		
		List<OrderItem> list2 = orderItemDao.selectBeanList(0, 9999, " where order.id= "+bean.getId());
		for(OrderItem oi:list2){
			Product product = productDao.selectBean(" where id= "+oi.getProduct().getId() );
			User user = userDao.selectBean(" where id= "+bean.getUser().getId());
			//生成用户评价
			Pingjia pingjia = new Pingjia();
			pingjia.setProduct(product);
			pingjia.setUser(user);
			pingjia.setPingjiastatus("未评价");
			pingjiaDao.insertBean(pingjia);
			
			//用户购买习惯数据采集
			Tongji2 t2  = tongji2Dao.selectBean(" where user.id= "+user.getId()+" and fenlei.id= "+product.getFenlei().getId());
			if(t2==null){
				t2 = new Tongji2();
				t2.setFenlei(product.getFenlei());
				t2.setUser(user);
				t2.setCount(1);
				t2.setJine(oi.getProductnum()*oi.getPrice());
				tongji2Dao.insertBean(t2);
			}else{
				t2.setCount(t2.getCount()+1);
				t2.setJine(t2.getJine()+oi.getProductnum()*oi.getPrice());
				tongji2Dao.updateBean(t2);
			}
			
		}
		
		
		
		
		
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!orderlist'; </script>");
		
	}
	

	
	//删除订单
	public void orderDel() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		Order bean = orderDao.selectBean(" where id= "+request.getParameter("id"));
		
		
		List<OrderItem> list2 = orderItemDao.selectBeanList(0, 9999, " where order.id= "+bean.getId());
		for(OrderItem oi:list2){
			orderItemDao.deleteBean(oi);

		}
		orderDao.deleteBean(bean);
		
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!orderlist'; </script>");
	}	
	
	//订单详细信息列表
	public String orderItemlist(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String orderid = request.getParameter("orderid");

		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		
		
		if(orderid !=null &&!"".equals(orderid)){
			sb.append(" orderid ="+orderid);
			sb.append(" and ");
			sb2.append(" orderid ="+orderid);
			sb2.append(" and ");
			request.setAttribute("orderid", orderid);
		}
		
		sb.append(" 1=1 order by id desc ");
		sb2.append(" 1=1 ");
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = orderItemDao.selectBeanCount(where2);
		List<OrderItem> list = orderItemDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!orderItemlist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		request.setAttribute("url", "method!orderItemlist");
		request.setAttribute("url2", "method!orderItem");
		request.setAttribute("titletitle", "订单信息管理");
		this.setUrl("orderitem/orderitemlist.jsp");
		return SUCCESS;
	}
	
	private UserDao userDao;
	
	
	public UserDao getUserDao() {
		return userDao;
	}


	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}


	//会员信息列表
	public String userlist(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String username = request.getParameter("username");
		String truename = request.getParameter("truename");
	
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		if(username !=null &&!"".equals(username)){
			sb.append(" username like '%"+username+"%' ");
			sb.append(" and ");
			sb2.append(" username like '%"+username+"%' ");
			sb2.append(" and ");
			request.setAttribute("username", username);
		}
		
		if(truename !=null &&!"".equals(truename)){
			sb.append(" truename like '%"+truename+"%' ");
			sb.append(" and ");
			sb2.append(" truename like '%"+truename+"%' ");
			sb2.append(" and ");
			request.setAttribute("truename", truename);
		}
		
		
		
		sb.append(" userlock=0 order by id desc ");
		sb2.append(" userlock=0 ");
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = userDao.selectBeanCount(where2);
		List<User> list = userDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!userlist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		request.setAttribute("url", "method!userlist");
		request.setAttribute("url2", "method!user");
		request.setAttribute("titletitle", "会员信息管理");
		this.setUrl("user/userlist.jsp");
		return SUCCESS;
	}
	
	
	//删除会员操作
	public void userdelete() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		User bean = userDao.selectBean(" where id= "+request.getParameter("id"));
		bean.setUserlock(1);
		userDao.updateBean(bean);
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!userlist'; </script>");
		
	}
	
	
	private PingjiaDao pingjiaDao;


	public PingjiaDao getPingjiaDao() {
		return pingjiaDao;
	}


	public void setPingjiaDao(PingjiaDao pingjiaDao) {
		this.pingjiaDao = pingjiaDao;
	}
	
	
	
	
	
	//评价信息管理信息列表
	public String pingjialist(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String pingjia = request.getParameter("pingjia");

	
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		if(pingjia !=null &&!"".equals(pingjia)){
			sb.append(" pingjia like '%"+pingjia+"%' ");
			sb.append(" and ");
			sb2.append(" pingjia like '%"+pingjia+"%' ");
			sb2.append(" and ");
			request.setAttribute("pingjia", pingjia);
		}

		sb.append(" pingjialock=0 order by id desc ");
		sb2.append(" pingjialock=0 ");
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = pingjiaDao.selectBeanCount(where2);
		List<Pingjia> list = pingjiaDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!pingjialist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		request.setAttribute("url", "method!pingjialist");
		request.setAttribute("url2", "method!pingjia");
		request.setAttribute("titletitle", "评价信息管理");
		this.setUrl("pingjia/pingjialist.jsp");
		return SUCCESS;
	}
	
	
	//删除评价信息管理操作
	public void pingjiadelete() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		Pingjia bean = pingjiaDao.selectBean(" where id= "+request.getParameter("id"));
		bean.setPingjialock(1);
		pingjiaDao.updateBean(bean);
		Product p = bean.getProduct();
		p.setPingjiashuliang(p.getPingjiashuliang()-1);
		productDao.updateBean(p);
		
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='method!pingjialist'; </script>");
		
	}
	
	
	
	
	//订单信息查询列表（按时间查询）
	public String orderlist2(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String time1 = request.getParameter("time1");
		String time2 = request.getParameter("time2");

		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		if(time1 !=null &&!"".equals(time1)){
			sb.append(" createtime >= '"+time1+"' ");
			sb.append(" and ");
			sb2.append(" createtime >= '"+time1+"' ");
			sb2.append(" and ");
			request.setAttribute("time1", time1);
		}
		
		if(time2 !=null &&!"".equals(time2)){
			sb.append(" createtime <= '"+time2+"' ");
			sb.append(" and ");
			sb2.append(" createtime <= '"+time2+"' ");
			sb2.append(" and ");
			request.setAttribute("time2", time2);
		}
		
		
		sb.append(" 1=1 order by id desc ");
		sb2.append(" 1=1 ");
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = orderDao.selectBeanCount(where2);
		List<Order> list = orderDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!orderlist2", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		request.setAttribute("url", "method!orderlist2");
		request.setAttribute("url2", "method!order");
		request.setAttribute("titletitle", "订单信息管理");
		this.setUrl("order/orderlist2.jsp");
		return SUCCESS;
	}
	
	
	
	//彩票销量图表统计
	public String tongjilist() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();

		String fenlei = request.getParameter("fenlei");
		request.setAttribute("fenleilist", fenleiDao.selectBeanList(0, 9999, " where  fenleilock=0 "));

		StringBuffer sb = new StringBuffer();
		sb.append(" where ");

		if(fenlei !=null &&!"".equals(fenlei)){
			sb.append(" fenlei.name like '%"+fenlei+"%' ");
			sb.append(" and ");
			request.setAttribute("fenlei", fenlei);
		}
		
		sb.append(" productlock=0 order by id desc ");

		String where = sb.toString();


		
		List<Product> list = productDao.selectBeanList(0, 9999, where);
		
		int zongxiaoliang = 0;
		for(Product p:list){
			zongxiaoliang+=p.getXiaoliang();
		}
		
		//jfree组件，专门用来画图
		
		
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		
		for(Product p:list){
			dataset.addValue(((double)p.getXiaoliang()/zongxiaoliang)*100, p.getName(),p.getName()+"销量："+p.getXiaoliang());		
		}
		JFreeChart chart = ChartFactory.createBarChart3D(null, "销量统计","百分比（%）", dataset, PlotOrientation.VERTICAL, true, false,false); 
		
		//柱状图(CategoryPlot):   
	CategoryPlot plot=chart.getCategoryPlot();
		//获取图表区域对象   
	CategoryAxis domainAxis=plot.getDomainAxis();    
		//水平底部列表    
	domainAxis.setLabelFont(new Font("黑体",Font.BOLD,14));    
		//水平底部标题    
	domainAxis.setTickLabelFont(new Font("宋体",Font.BOLD,12));
		//垂直标题    
	ValueAxis rangeAxis=plot.getRangeAxis();
		//获取柱状    
	rangeAxis.setLabelFont(new Font("黑体",Font.BOLD,15));     
	chart.getLegend().setItemFont(new Font("黑体", Font.BOLD, 15));
		
	String s = new Date().getTime()+"";
	request.setAttribute("time", s);
	
	String savaPath = ServletActionContext.getServletContext().getRealPath(
		"/")
		+ "/productimg/"+s+".png";
		
	ChartUtilities.saveChartAsPNG(new File(savaPath), chart, 1200, 400); 

	this.setUrl("tongji/tongjilist.jsp");
	
	return SUCCESS;
	}
	
	//彩票金额图表统计
	public String tongjilist2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();

		String fenlei = request.getParameter("fenlei");
		request.setAttribute("fenleilist", fenleiDao.selectBeanList(0, 9999, " where  fenleilock=0 "));

		StringBuffer sb = new StringBuffer();
		sb.append(" where ");

		if(fenlei !=null &&!"".equals(fenlei)){
			sb.append(" fenlei.name like '%"+fenlei+"%' ");
			sb.append(" and ");
			request.setAttribute("fenlei", fenlei);
		}
		
		sb.append(" productlock=0 order by id desc ");

		String where = sb.toString();


		
		List<Product> list = productDao.selectBeanList(0, 9999, where);
		
		
		Map<String,Double> map = new HashMap<String,Double> ();
		double count = 0;//所有彩票总的金额
		for(Product p:list){
			List<OrderItem> list2 = orderItemDao.selectBeanList(0, 9999, " where product.id= "+p.getId());
			double c = 0;//这个彩票总的金额
			for(OrderItem oi:list2){
				c = c+(oi.getProductnum()*oi.getPrice());
			}
			map.put(p.getId()+","+p.getName(), c);
			count = count+c;
		}
		
		Set<String> set =map.keySet();
		
		
		//jfree组件，专门用来画图
		
		
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		
		for(String sss:set){
			if(sss!=null){
				double cc = map.get(sss);//该彩票的总金额
				String ssss = sss.substring(sss.indexOf(",")+1,sss.length());//彩票的名字
				dataset.addValue(((double)cc/count)*100, ssss,ssss+"总金额："+cc);	
			}
			
				
		}
		JFreeChart chart = ChartFactory.createBarChart3D(null, "彩票总金额统计","百分比（%）", dataset, PlotOrientation.VERTICAL, true, false,false); 
		
		//柱状图(CategoryPlot):   
	CategoryPlot plot=chart.getCategoryPlot();
		//获取图表区域对象   
	CategoryAxis domainAxis=plot.getDomainAxis();    
		//水平底部列表    
	domainAxis.setLabelFont(new Font("黑体",Font.BOLD,14));    
		//水平底部标题    
	domainAxis.setTickLabelFont(new Font("宋体",Font.BOLD,12));
		//垂直标题    
	ValueAxis rangeAxis=plot.getRangeAxis();
		//获取柱状    
	rangeAxis.setLabelFont(new Font("黑体",Font.BOLD,15));     
	chart.getLegend().setItemFont(new Font("黑体", Font.BOLD, 15));
		
	String s = new Date().getTime()+"";
	request.setAttribute("time", s);
	
	String savaPath = ServletActionContext.getServletContext().getRealPath(
		"/")
		+ "/productimg/"+s+".png";
		
	ChartUtilities.saveChartAsPNG(new File(savaPath), chart, 1200, 400); 

	this.setUrl("tongji/tongjilist2.jsp");
	
	return SUCCESS;
	}
	
	private TongjiDao tongjiDao;


	public TongjiDao getTongjiDao() {
		return tongjiDao;
	}


	public void setTongjiDao(TongjiDao tongjiDao) {
		this.tongjiDao = tongjiDao;
	}
	
	
	
	//彩票销量排行榜
	public String tongjilist4(){
		HttpServletRequest request = ServletActionContext.getRequest();
		
		List<Product> list = productDao.selectBeanList(0, 9999, " where productlock=0 ");
		
		Map<String,Integer> map = new HashMap<String,Integer> ();
	
		for(Product p:list){
			List<OrderItem> list2 = orderItemDao.selectBeanList(0, 9999, " where product.id= "+p.getId());
			int c = 0;//这个彩票的总销量
			for(OrderItem oi:list2){
				c += oi.getProductnum();
			}
			map.put(p.getId()+"", c);
		}
		
		Set<String> set =map.keySet();
		
		List<Tongji> list2 = tongjiDao.selectBeanList(0, 9999, " where 1=1 ");
		for(Tongji t:list2){
			tongjiDao.deleteBean(t);
		}
		for(String s:set){
			Tongji tongji = new Tongji();
			tongji.setProduct(productDao.selectBean(" where id= "+s));
			tongji.setXiaoliang(map.get(s));
			tongjiDao.insertBean(tongji);
			
		}
		
		
		
		
		String name = request.getParameter("name");
		String fenlei = request.getParameter("fenlei");
		request.setAttribute("fenleilist", fenleiDao.selectBeanList(0, 9999, " where  fenleilock=0 "));
		

		
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		if(name !=null &&!"".equals(name)){
			sb.append(" product.name like '%"+name+"%' ");
			sb.append(" and ");
			sb2.append(" product.name like '%"+name+"%' ");
			sb2.append(" and ");
			request.setAttribute("name", name);
		}
		
		if(fenlei !=null &&!"".equals(fenlei)){
			sb.append(" product.fenlei.name like '%"+fenlei+"%' ");
			sb.append(" and ");
			sb2.append(" product.fenlei.name like '%"+fenlei+"%' ");
			sb2.append(" and ");
			request.setAttribute("fenlei", fenlei);
		}
		
		
		
		sb.append(" 1=1 order by xiaoliang desc ");
		sb2.append(" 1=1 ");
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = tongjiDao.selectBeanCount(where2);
		List<Tongji> list4 = tongjiDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list4);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!tongjilist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		request.setAttribute("url", "method!tongjilist4");

		request.setAttribute("titletitle", "彩票销量排行榜");
		this.setUrl("tongji/tongjilist4.jsp");
		return SUCCESS;
	}
	
	
	//彩票金额排行榜
	public String tongjilist5(){
		HttpServletRequest request = ServletActionContext.getRequest();
		
		List<Product> list = productDao.selectBeanList(0, 9999, " where productlock=0 ");
		
		Map<String,Double> map = new HashMap<String,Double> ();
	
		for(Product p:list){
			List<OrderItem> list2 = orderItemDao.selectBeanList(0, 9999, " where product.id= "+p.getId());
			double c = 0;//这个彩票的总金额
			for(OrderItem oi:list2){
				c += oi.getProductnum()*oi.getPrice();
			}
			map.put(p.getId()+"", c);
		}
		
		Set<String> set =map.keySet();
		
		List<Tongji> list2 = tongjiDao.selectBeanList(0, 9999, " where 1=1 ");
		for(Tongji t:list2){
			tongjiDao.deleteBean(t);
		}
		for(String s:set){
			Tongji tongji = new Tongji();
			tongji.setProduct(productDao.selectBean(" where id= "+s));
			tongji.setZongjine(map.get(s));
			tongjiDao.insertBean(tongji);
			
		}
		
		
		
		
		String name = request.getParameter("name");
		String fenlei = request.getParameter("fenlei");
		request.setAttribute("fenleilist", fenleiDao.selectBeanList(0, 9999, " where  fenleilock=0 "));
		

		
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		if(name !=null &&!"".equals(name)){
			sb.append(" product.name like '%"+name+"%' ");
			sb.append(" and ");
			sb2.append(" product.name like '%"+name+"%' ");
			sb2.append(" and ");
			request.setAttribute("name", name);
		}
		
		if(fenlei !=null &&!"".equals(fenlei)){
			sb.append(" product.fenlei.name like '%"+fenlei+"%' ");
			sb.append(" and ");
			sb2.append(" product.fenlei.name like '%"+fenlei+"%' ");
			sb2.append(" and ");
			request.setAttribute("fenlei", fenlei);
		}
		
		
		
		sb.append(" 1=1 order by zongjine desc ");
		sb2.append(" 1=1 ");
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = tongjiDao.selectBeanCount(where2);
		List<Tongji> list4 = tongjiDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list4);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!tongjilist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		request.setAttribute("url", "method!tongjilist5");

		request.setAttribute("titletitle", "彩票金额排行榜");
		this.setUrl("tongji/tongjilist5.jsp");
		return SUCCESS;
	}
	
	
	private Tongji2Dao tongji2Dao;


	public Tongji2Dao getTongji2Dao() {
		return tongji2Dao;
	}


	public void setTongji2Dao(Tongji2Dao tongji2Dao) {
		this.tongji2Dao = tongji2Dao;
	}
	
	
	//用户购买习惯分析
	public String tongji2list(){
		HttpServletRequest request = ServletActionContext.getRequest();
	
		String username = request.getParameter("username");
	
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		StringBuffer sb2 = new StringBuffer();
		sb2.append(" where ");
		
		
		if(username !=null &&!"".equals(username)){
			sb.append(" user.username like '%"+username+"%' ");
			sb.append(" and ");
			sb2.append(" user.username like '%"+username+"%' ");
			sb2.append(" and ");
			request.setAttribute("username", username);
		}
		
		
		
		sb.append(" 1=1 order by id desc ");
		sb2.append("1=1 ");
		String where = sb.toString();
		String where2 = sb2.toString();

		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = tongji2Dao.selectBeanCount(where2);
		List<Tongji2> list = tongji2Dao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!tongji2list", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		request.setAttribute("url", "method!tongji2list");

		request.setAttribute("titletitle", "用户购买习惯分析");
		this.setUrl("tongji/tongjilist6.jsp");
		return SUCCESS;
	}
	
	

}

package cn.itbaizhan.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import cn.itbaizhan.model.CartItem;
import cn.itbaizhan.model.Product;

public class CartService {

	private static HashMap<Integer,CartItem> items = new HashMap<Integer,CartItem>();
	
	//添加彩票到彩票预定车
	public static boolean addItem(Product product){
		if(!items.containsKey((int)product.getId())){
			CartItem item = new CartItem();
			item.setDrop(false);
			item.setNumber(1);
			item.setProduct(product);
			items.put((int)product.getId(), item);
			return true;
		}
		return false;
	}
	
	//清空彩票预定车
	public static void clear(){
		items.clear();
	}
	
	//删除彩票预定车里的彩票
	public static boolean drop(int pid){
		if(items.containsKey(pid)){
			CartItem item = items.get(pid);
			item.setDrop(true);
			return true;
		}
		return false;
		
	}
	
	//获得彩票预定车里未删除的购物条目的信息
	public static List<CartItem> getItems(){
		ArrayList<CartItem> list = new ArrayList<CartItem>();
		Iterator<Integer> it =  items.keySet().iterator();
		while(it.hasNext()){
			CartItem item = items.get(it.next());
			if(!item.isDrop()){
				list.add(item);
			}
		}
		return list;
	}
	
	
	//获得彩票预定车里删除的购物条目的信息
	public static List<CartItem> getDropItems(){
		ArrayList<CartItem> list = new ArrayList<CartItem>();
		Iterator<Integer> it =  items.keySet().iterator();
		while(it.hasNext()){
			CartItem item = items.get(it.next());
			if(item.isDrop()){
				list.add(item);
			}
		}
		return list;
	}
	
	//计算彩票预定车总的原价
	public static double getPrice1(){
		double totalPrice = 0;
		Iterator<Integer> it =  items.keySet().iterator();
		while(it.hasNext()){
			CartItem item = items.get(it.next());
			if(!item.isDrop()){
				totalPrice+=item.getProduct().getPrice1()*item.getNumber();
			}
		}
		return totalPrice;
	}
	
	
	//计算彩票预定车总的优惠价
	public static double getPrice2(){
		double totalPrice = 0;
		Iterator<Integer> it =  items.keySet().iterator();
		while(it.hasNext()){
			CartItem item = items.get(it.next());
			if(!item.isDrop()){
				totalPrice+=item.getProduct().getPrice2()*item.getNumber();
			}
		}
		return totalPrice;
	}
	
	//判断彩票预定车是否为空
	public static boolean isEmpty(){
		return items.isEmpty();
	}
	
	//恢复彩票预定车里删除的彩票
	public static boolean recovery(int pid){
		if(items.containsKey(pid)){
			CartItem item = items.get(pid);
			item.setDrop(false);
			return true;
		}
		return false;
	}
	
	//更新彩票预定车里面的彩票数量
	public static boolean updateNum(int pid,int num){
		if(items.containsKey(pid)){
			CartItem item = items.get(pid);
			item.setNumber(num);
			return true;
		}
		return false;
	}
	
	
	
	
	

	
}
